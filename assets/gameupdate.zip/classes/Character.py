class Character:
    def __init__(self, name="Character"):
        self.name = name
#TODO Again I need to know more about how the game deals with characters, both friend and foe, before I can complete this.
